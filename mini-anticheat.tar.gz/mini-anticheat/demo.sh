#!/usr/bin/env bash
# Reproduce the whole demo: build, then show each check being DETECTED and
# then BYPASSED. Run from the project directory:  ./demo.sh
set -u
cd "$(dirname "$0")"
P=$PWD
rpt() { sed -n '/== sentinel/,/VERDICT/p'; }   # trim gdb / loader noise

make --silent clean && make --silent all && echo "(built)"

echo; echo "############ 1. CLEAN RUN ############"
./sentinel

echo; echo "############ 2. DEBUGGER — detected under gdb ############"
gdb -q -batch -ex run ./sentinel 2>/dev/null | rpt

echo; echo "############ 3. INJECTION — detected (LD_PRELOAD=injected.so) ############"
LD_PRELOAD=$P/injected.so ./sentinel 2>/dev/null | rpt

echo; echo "############ 4. TAMPER — naive code-only patch is caught ############"
python3 - <<'PY'
import shutil, elfpatch
shutil.copy2("sentinel","sentinel.naive")
off,_   = elfpatch.sym_off("sentinel.naive","license_check")
end,_   = elfpatch.symbol("sentinel.naive","license_check_end")
start,_ = elfpatch.symbol("sentinel.naive","license_check")
code = bytearray(elfpatch.read_at("sentinel.naive",off,end-start))
i = code.find(bytes([0xB8,0,0,0,0]))
elfpatch.write_at("sentinel.naive", off+i, bytes([0xB8,1,0,0,0]))
print(f"flipped return 0 -> return 1 at {off+i:#x}; baseline left untouched")
PY
./sentinel.naive | rpt

echo; echo "############ 5. INJECTION BYPASS — bypass.so hides itself ############"
LD_PRELOAD=$P/bypass.so ./sentinel | rpt

echo; echo "############ 6. DEBUGGER BYPASS — under gdb WITH bypass.so ############"
gdb -q -batch -ex "set exec-wrapper env LD_PRELOAD=$P/bypass.so" -ex run ./sentinel 2>/dev/null | rpt

echo; echo "############ 7. TAMPER BYPASS — patch code + rewrite baseline ############"
python3 patch_binary.py ./sentinel ./sentinel.cheated
./sentinel.cheated | rpt
