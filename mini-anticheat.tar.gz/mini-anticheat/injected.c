/* A stand-in for a hostile injected module: it loads, runs a constructor,
   and (unlike bypass.so) makes no attempt to hide. The sentinel should see it. */
#include <stdio.h>
__attribute__((constructor))
static void on_load(void){ fprintf(stderr, "[injected.so] constructor ran\n"); }
