#!/usr/bin/env python3
"""
patch_binary.py <sentinel> [<output>]

Defeats CHECK 2 (code integrity).  Two steps, and the second is the lesson:

  1. Patch license_check() so it returns 1 (LICENSED) instead of 0.
     At -O0 the `return 0;` path is `mov eax, 0` == b8 00 00 00 00; we flip
     the immediate to get `mov eax, 1` == b8 01 00 00 00.

  2. The sentinel would now notice, because its FNV-1a of license_check no
     longer matches g_expected_checksum.  So we recompute the checksum over
     the *patched* bytes and overwrite g_expected_checksum to match.

The reference value lives in the same file we are editing, so step 2 is free.
That is why a client-side self-checksum cannot establish its own integrity.
"""
import shutil
import sys
import elfpatch

FNV_OFFSET = 2166136261
FNV_PRIME = 16777619

RET0 = bytes([0xB8, 0x00, 0x00, 0x00, 0x00])   # mov eax, 0   (return 0)
RET1 = bytes([0xB8, 0x01, 0x00, 0x00, 0x00])   # mov eax, 1   (return 1)


def fnv1a(data):
    h = FNV_OFFSET
    for b in data:
        h ^= b
        h = (h * FNV_PRIME) & 0xFFFFFFFF
    return h


def main(src, dst=None):
    dst = dst or src + ".cheated"
    if dst != src:
        shutil.copy2(src, dst)

    # Locate license_check and its length (end marker - start).
    fn_off, _ = elfpatch.sym_off(dst, "license_check")
    end_vaddr, _ = elfpatch.symbol(dst, "license_check_end")
    start_vaddr, _ = elfpatch.symbol(dst, "license_check")
    length = end_vaddr - start_vaddr

    code = bytearray(elfpatch.read_at(dst, fn_off, length))

    # Step 1: flip `return 0` -> `return 1`.
    i = code.find(RET0)
    if i < 0:
        sys.exit("could not find `mov eax,0` (return 0) -- different codegen?")
    code[i:i + len(RET0)] = RET1
    elfpatch.write_at(dst, fn_off + i, RET1)
    print(f"[1] patched return 0 -> return 1 at file offset {fn_off + i:#x}")

    # Step 2: recompute checksum over patched bytes, rewrite the baseline.
    new_sum = fnv1a(bytes(code))
    old_sum, bo = elfpatch.read_u32(dst, "g_expected_checksum")
    elfpatch.write_u32(dst, "g_expected_checksum", new_sum)
    print(f"[2] rewrote g_expected_checksum {old_sum:#010x} -> {new_sum:#010x} "
          f"at file offset {bo:#x}")
    print(f"done -> {dst}")


if __name__ == "__main__":
    main(*sys.argv[1:3])
