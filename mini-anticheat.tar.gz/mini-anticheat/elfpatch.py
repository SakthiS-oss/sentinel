"""
elfpatch.py -- minimal ELF symbol locator + byte patcher (no dependencies).

Parses `readelf` text to map a symbol name to a file offset, then reads or
writes raw bytes there.  Works because sentinel is linked -no-pie, so symbol
values are absolute virtual addresses and the vaddr->file-offset mapping is a
simple per-section shift:  off = vaddr - section.addr + section.off

The honest build (embed_baseline.py) and the attacker (patch_binary.py) both
use this -- that symmetry is the point: the "trusted" checksum lives in a file
the attacker can edit with the very same tool the defender used.
"""
import re
import subprocess


def _run(*args):
    return subprocess.run(args, capture_output=True, text=True, check=True).stdout


def sections(path):
    """[(addr, off, size)] for PROGBITS-ish sections, from readelf -SW."""
    out = _run("readelf", "-SW", path)
    secs = []
    for line in out.splitlines():
        # e.g.  [13] .text   PROGBITS  0000...1060 001060 0001f5 00 AX 0 0 16
        m = re.search(r"\]\s+\S+\s+\S+\s+([0-9a-fA-F]+)\s+([0-9a-fA-F]+)\s+([0-9a-fA-F]+)", line)
        if not m:
            continue
        addr, off, size = (int(g, 16) for g in m.groups())
        if addr != 0 and size != 0:
            secs.append((addr, off, size))
    return secs


def symbol(path, name):
    """(vaddr, size) for a symbol, from readelf -sW."""
    out = _run("readelf", "-sW", path)
    for line in out.splitlines():
        parts = line.split()
        # Num: Value Size Type Bind Vis Ndx Name
        if len(parts) >= 8 and parts[-1] == name and parts[0].endswith(":"):
            return int(parts[1], 16), int(parts[2])
    raise KeyError(f"symbol {name!r} not found in {path}")


def vaddr_to_off(path, vaddr):
    for addr, off, size in sections(path):
        if addr <= vaddr < addr + size:
            return off + (vaddr - addr)
    raise ValueError(f"vaddr {vaddr:#x} is not inside any section")


def sym_off(path, name):
    """(file_offset, size) for a symbol's bytes in the file."""
    vaddr, size = symbol(path, name)
    return vaddr_to_off(path, vaddr), size


def read_at(path, off, n):
    with open(path, "rb") as f:
        f.seek(off)
        return f.read(n)


def write_at(path, off, data):
    with open(path, "r+b") as f:
        f.seek(off)
        f.write(data)


def read_u32(path, name):
    off, _ = sym_off(path, name)
    return int.from_bytes(read_at(path, off, 4), "little"), off


def write_u32(path, name, value):
    off, _ = sym_off(path, name)
    write_at(path, off, (value & 0xFFFFFFFF).to_bytes(4, "little"))
    return off
