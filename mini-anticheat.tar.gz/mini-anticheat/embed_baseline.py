#!/usr/bin/env python3
"""
embed_baseline.py <sentinel-binary>

Build step (honest side): ask the freshly built binary for the checksum of its
pristine license_check(), then bake that value into g_expected_checksum so the
code-integrity check passes on an untouched binary.
"""
import subprocess
import sys
import elfpatch

def main(path):
    checksum = subprocess.run(
        [path, "--emit-baseline"], capture_output=True, text=True, check=True
    ).stdout.strip()
    value = int(checksum, 16)
    off = elfpatch.write_u32(path, "g_expected_checksum", value)
    print(f"embedded baseline checksum {value:#010x} at file offset {off:#x}")

if __name__ == "__main__":
    main(sys.argv[1])
